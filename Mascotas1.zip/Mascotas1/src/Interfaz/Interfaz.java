/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Interfaz;

import Mundo.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author SG702-10
 */
public class Interfaz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ArrayList<Persona> Usuarios = new ArrayList<>();
        /*menu selecione el propetario
                pedir el correo
                        
           menus este llamar mascota*/
        int opcion = 0;
    }

    private Persona crearPersona() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre de la persona");
        String nombre = sc.nextLine();
        System.out.println("Ingrese la fecha de nacimiento del usuario");
        int FechaDeNacimiento = sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese el telefono del usuario");
        String telefono = sc.nextLine();
        System.out.println("Ingrese el correo del usuario");
        String email = sc.nextLine();
        Persona persona = new Persona(nombre, FechaDeNacimiento, telefono, email);
        return persona;
    }

    private Perro crearPerro() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre");
        String nombre = sc.nextLine();
        System.out.println("Ingrese la raza  ");
        String raza = sc.nextLine();
        System.out.println("Ingrese el genero  ");
        String genero = sc.nextLine();
        System.out.println("Ingrese la fecha de Nacimiento  ");
        int fechadeNacimiento = sc.nextInt();
        sc.nextLine();
        Perro perro = new Perro(raza, genero, nombre, fechadeNacimiento);
        return perro;

    }

    private Ave crearAve() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre");
        String nombre = sc.nextLine();
        System.out.println("Ingrese la raza  ");
        String raza = sc.nextLine();
        System.out.println("Ingrese el genero  ");
        String genero = sc.nextLine();
        System.out.println("Ingrese la fecha de Nacimiento  ");
        int fechadeNacimiento = sc.nextInt();
        sc.nextLine();
        Ave ave = new Ave(raza, genero, nombre, fechadeNacimiento);
        return ave;
    }

    private Pez crearpez() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre");
        String nombre = sc.nextLine();
        System.out.println("Ingrese la raza  ");
        String raza = sc.nextLine();
        System.out.println("Ingrese el genero  ");
        String genero = sc.nextLine();
        System.out.println("Ingrese la fecha de Nacimiento  ");
        int fechadeNacimiento = sc.nextInt();
        sc.nextLine();
        Pez pez = new Pez(raza, genero, nombre, fechadeNacimiento);
        return pez;
    }

    private Planta crearplanta() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el nombre");
        String nombre = sc.nextLine();
        System.out.println("Ingrese el tipo ");
        String tipo = sc.nextLine();
        System.out.println("Ingrese el color   ");
        String color = sc.nextLine();
        System.out.println("Ingrese la especie  ");
        String especie = sc.nextLine();
        Planta planta = new Planta(especie, color, tipo, nombre);
        return planta;


        /*
    devolver un persona 
    persona (nombre todo)
            
            
            menu 
    crear servivo me devuelve un servivo 
        crar planta
            
        crear animal 
               crear perro
               crear pez
               crear ave
      >*/
    }
}