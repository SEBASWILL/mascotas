/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mundo;

/**
 *
 * @author SG702-15
 */
public class Pez extends Mascota {

    public Pez(String RAZA, String GENERO, String NOMBRE, int FECHADENACIMIENTO) {
        super("PEZ", RAZA, GENERO, NOMBRE, FECHADENACIMIENTO);
    }

    public void moverse(int distancia) {
        System.out.println(NOMBRE + " nada " + distancia + " metros.");
    }

    @Override
    public String comunicarse() {
        return "glu glu";
    }

    @Override
    public String respirar() {
        return NOMBRE + "respira a través de las branquias";
    }

    @Override
    public String comer() {
        return NOMBRE + "esta comiendo Incros Gold Fish";
    }
}
