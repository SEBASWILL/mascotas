/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mundo;

/**
 *
 * @author SG702-15
 */
public class Perro extends Mascota {

    public Perro( String RAZA, String GENERO, String NOMBRE, int FECHADENACIMIENTO) {
        super("PERRO", RAZA, GENERO, NOMBRE, FECHADENACIMIENTO);
    }

    public void moverse(int distancia) {
        System.out.println(NOMBRE + " corre " + distancia + " metros.");
    }

    @Override
    public String respirar() {
        return NOMBRE+ "Respira a traves de los pulmones";
    }

    @Override
    public String comer() {
        return NOMBRE + "Esta comiendo Royal Canin";
    }

    @Override
    public String comunicarse() {
        return NOMBRE + "Esta ladradando : guau guau";
    }
}
