/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mundo;

/**
 *
 * @author SG702-15
 * 
 */
public class Ave extends Mascota {
    public Ave( String RAZA, String GENERO, String NOMBRE, int FECHADENACIMIENTO) {
        super("AVE", RAZA, GENERO, NOMBRE, FECHADENACIMIENTO);
    }

    
    public void moverse(int distancia) {
        System.out.println(NOMBRE + " vuela " + distancia + " metros.");
    }

    

    @Override
    public String respirar() {
        return NOMBRE+ "Respira a traves de los pulmones";
    }

    @Override
    public String comer() {
        return NOMBRE + "Esta comiendo Pharmavet";
    }

    @Override
    public String comunicarse() {
        return NOMBRE+ "chirp chirp chirp";
        
    }
}